<?php
/**
 * Plugin Name: TH Report
 * Description: Generate JSON current, and monthly technical reports through integration with Cloudways. Purposefully built to plug-in to Adobe Document Generation API.
 * Version: 1.0.6
 * Author: Tomorrow Happens
 * Author URI: https://tomorrow-happens.com.au
 * Developer: Alex Fesenko
 * Text Domain: th-report
 * Domain Path: /languages
 * Update URI:  https://raw.githubusercontent.com/Tomorrow-Happens/th-report-update/main/version.json
 */

if (!defined('ABSPATH')) {
    exit();
}

if (!class_exists('TH_Tech_Report')):
    /**
     * Main TH_Tech_Report class.
     */
    final class TH_Tech_Report
    {
        /**
         * @var string
         */
        public $version;

        /**
         * @var string
         */
        public $UpdateURI;

        /**
         * @var string
         */
        public $plugin_slug;

        /**
         * @var string
         */
        public $cache_key = 'th_report_plugin_update';

        /**
         * @var bool
         */
        public $cache_allowed = false;

        /**
         * @var obj
         */
        public $checked;

        /**
         *  Instance.
         *
         * @var TH_Tech_Report the Instance
         */
        protected static $_instance;

        /**
         * Main TH_Tech_Report Instance.
         *
         * Ensures that only one instance of TH_Tech_Report exists in memory at any one
         * time. Also prevents needing to define globals all over the place.
         *
         * @return TH_Tech_Report
         */
        public static function instance()
        {
            if (is_null(self::$_instance)) {
                try {
                    self::$_instance = new self();
                } catch (\Throwable $th) {
                    return null;
                }
            }

            return self::$_instance;
        }

        /**
         * Get running.
         *
         * @return void
         */
        public function __construct()
        {
            $this->setup_constants();
            $this->includes();
            $this->init_hooks();
        }

        /**
         * Setup plugin constants.
         *
         * @return void
         */
        private function setup_constants()
        {

            // Plugin Folder Path.
            if (!defined('TH_PLUGIN_DIR')) {
                define('TH_PLUGIN_DIR', plugin_dir_path(__FILE__));
            }

            // Plugin Folder Path.
            if (!defined('TH_PLUGIN_ID')) {
                define(
                    'TH_PLUGIN_ID',
                    str_replace(WP_PLUGIN_DIR . '/', '', __FILE__)
                );
            }

            // Plugin Folder URL.
            if (!defined('TH_PLUGIN_URL')) {
                define('TH_PLUGIN_URL', plugin_dir_url(__FILE__));
            }

            // Plugin Root File.
            if (!defined('TH_PLUGIN_FILE')) {
                define('TH_PLUGIN_FILE', __FILE__);
            }
        }

        /**
         * Load plugins required files.
         *
         * @return void
         */
        private function includes()
        {
            require_once TH_PLUGIN_DIR . 'includes/th-report-api.php';
            require_once TH_PLUGIN_DIR . 'includes/th-cloudways.php';
            require_once TH_PLUGIN_DIR . 'includes/th-webpagetest.php';
            require_once TH_PLUGIN_DIR . 'includes/th-report.php';
            require_once TH_PLUGIN_DIR . 'includes/th-cron.php';
            require_once TH_PLUGIN_DIR . 'includes/th-ajax.php';
            require_once TH_PLUGIN_DIR . 'includes/th-options.php';
            require_once TH_PLUGIN_DIR . 'includes/th-pages.php';
        }

        /**
         * Hook in our actions and filters.
         *
         * @return void
         */
        private function init_hooks()
        {
            register_activation_hook(TH_PLUGIN_FILE, [$this, 'install']);
            register_deactivation_hook(TH_PLUGIN_FILE, [$this, 'uninstall']);
            add_action('plugins_loaded', [$this, 'load_textdomain'], 0);
            add_action('plugins_loaded', [$this, 'init'], 0);

            if (version_compare(get_bloginfo('version'), '5.8', '<')) {
                add_filter('site_transient_update_plugins', [$this, 'update']);
            } else {
                add_filter(
                    'update_plugins_raw.githubusercontent.com',
                    [$this, 'check_for_updates'],
                    10,
                    3
                );
            }

            add_action('admin_init', [$this, 'admin_init'], 0);
        }

        /**
         * Install plugin.
         *
         * @return void
         */
        public function install()
        {
            TH_Cron::install();
        }

        /**
         * Uninstall plugin.
         *
         * @return void
         */
        public function uninstall()
        {
            TH_Cron::uninstall();
        }

        /**
         * Load plugin textdomain.
         *
         * @return void
         */
        public function load_textdomain()
        {
            load_plugin_textdomain(
                'th-report',
                false,
                basename(dirname(__FILE__)) . '/languages'
            );
        }

        /**
         * Hook into WordPress once all plugins are loaded.
         *
         * @return void
         */
        public function init()
        {
            add_action('admin_menu', [$this, 'admin_menu'], 0);
            new TH_Cron();
        }

        /**
         * Hook into WordPress init when a user accesses the admin area.
         *
         * @return void
         */
        public function admin_init()
        {
            $plugin_data = get_plugin_data(__FILE__);

            $this->version = $plugin_data['Version'];
            $this->UpdateURI = $plugin_data['UpdateURI'];
            $this->plugin_slug = plugin_basename(__DIR__);

            // Plugin version.
            if (!defined('TH_VERSION')) {
                define('TH_VERSION', $this->version);
            }
            new TH_Ajax();
            $this->plugin_settings();
        }

        /**
         * Add plugin settings into WordPress .
         *
         * @return void
         */
        private function plugin_settings()
        {
            $wpt = new TH_WPT();
            $locations = $wpt->getLocations();

            $options = new TH_Options('th_report_settings');
            $section = $options->add_section(
                'general',
                __('General', 'th-report')
            );
            $options->add_setting(
                'th_admin_email',
                __('Email for notifications', 'th-report'),
                $section,
                'text',
                true
            );
            $section = $options->add_section(
                'cloudways',
                __('Cloudways', 'th-report')
            );
            $options->add_setting(
                'th_cloudways_email',
                __('Email (required)', 'th-report'),
                $section,
                'text',
                true
            );
            $options->add_setting(
                'th_cloudways_key',
                __('API Key (required)', 'th-report'),
                $section,
                'password',
                true
            );
            $options->add_setting(
                'th_cloudways_site_id',
                __('Site ID (required)', 'th-report'),
                $section,
                'text',
                true
            );
            $section = $options->add_section(
                'webpagetest',
                __('Webpagetest', 'th-report')
            );
            $options->add_setting(
                'wpt_token',
                __('Token (required)', 'th-report'),
                $section,
                'password',
                true
            );
            $options->add_setting(
                'wpt_test_url',
                __('URL for test (optional)', 'th-report'),
                $section,
                'text',
                false,
                get_option( 'siteurl' )
            );
            $options->add_setting(
                'wpt_location',
                __('Location for test (optional)', 'th-report'),
                $section,
                'select',
                false,
                $locations
            );
            $section = $options->add_section(
                'report-api',
                __('Report Api', 'th-report')
            );
            $options->add_setting(
                'th_report_api_url',
                __('Report Api url (optional)', 'th-report'),
                $section,
                'text',
                false
            );
            $options->add_setting(
                'th_report_api_key',
                __('API Key (optional)', 'th-report'),
                $section,
                'password',
                false
            );
        }

        /**
         * Creating a plugin settings page.
         *
         * @return void
         */
        public function admin_menu()
        {
            $menu = new TH_Pages();
            $menu->add_page(__('Generate', 'th-report'), 'generate');
            $menu->add_page(__('Settings', 'th-report'), 'settings');
            $menu->add_page(__('Reports', 'th-report'), 'reports');
            $menu->init();
        }

        /**
         * Check for update plugin.
         *
         * @return object
         */
        public function check_for_updates($update, $plugin_data, $plugin_file)
        {
            static $response = false;

            if (empty($plugin_data['UpdateURI']) || !empty($update)) {
                return $update;
            }

            if ($response === false) {
                $response = wp_remote_get($plugin_data['UpdateURI']);
            }

            if (empty($response['body'])) {
                return $update;
            }

            $custom_plugins_data = json_decode($response['body'], true);

            if (!empty($custom_plugins_data[$plugin_file])) {
                return $custom_plugins_data[$plugin_file];
            } else {
                return $update;
            }
        }

        /**
         * Get data for plugin.
         *
         * @return object
         */
        private function request()
        {
            $remote = get_transient($this->cache_key);

            if (false === $remote || !$this->cache_allowed) {
                $remote = wp_remote_get($this->UpdateURI, [
                    'timeout' => 10,
                    'headers' => [
                        'Accept' => 'application/json',
                    ],
                ]);

                if (
                    is_wp_error($remote) ||
                    200 !== wp_remote_retrieve_response_code($remote) ||
                    empty(wp_remote_retrieve_body($remote))
                ) {
                    return false;
                }

                set_transient($this->cache_key, $remote, DAY_IN_SECONDS);
            }

            $remote = json_decode(wp_remote_retrieve_body($remote));

            return $remote;
        }

        /**
         * Set data for plugin.
         *
         * @return object
         */
        public function update($transient)
        {
            if (empty($transient->checked)) {
                return $transient;
            }

            $plugin_id = TH_PLUGIN_ID;
            if (empty($this->checked)) {
                $remote = $this->request();
                if (!$remote || empty($remote->$plugin_id)) {
                    return $transient;
                }
                $this->checked = $remote->$plugin_id;
            }
            if (empty($this->checked)) {
                return $transient;
            }

            if (version_compare($this->version, $this->checked->version, '<')) {
                $res = new stdClass();
                $res->slug = $this->plugin_slug;
                $res->plugin = plugin_basename(__FILE__);
                $res->new_version = $this->checked->version;
                $res->tested = get_bloginfo('version');
                $res->package = $this->checked->package;

                $transient->response[$res->plugin] = $res;
            }

            return $transient;
        }

        /**
         * Throw error on object clone.
         *
         * The whole idea of the singleton design pattern is that there is a single
         * object therefore, we don't want the object to be cloned.
         *
         * @return void
         */
        public function __clone()
        {
            // Cloning instances of the class is forbidden
            _doing_it_wrong(
                __FUNCTION__,
                __('Cheatin&#8217; huh?', 'th-report'),
                '1.0.0'
            );
        }

        /**
         * Disable unserializing of the class.
         *
         * @return void
         */
        public function __wakeup()
        {
            // Unserializing instances of the class is forbidden
            _doing_it_wrong(
                __FUNCTION__,
                __('Cheatin&#8217; huh?', 'th-report'),
                '1.0.0'
            );
        }
    }
endif;

/**
 * Start TH_Tech_Report.
 *
 * @return TH_Tech_Report
 */
function TH_Tech_Report()
{
    return TH_Tech_Report::instance();
}

TH_Tech_Report();
