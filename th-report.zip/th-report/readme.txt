=== TH Report ===
Contributors: Alex
Tags: report, info
Requires at least: 1.0
Tested up to: 5.8
Stable tag: 5.2.1
Requires PHP: 5.6.20



== Description ==

TH Report plugin

