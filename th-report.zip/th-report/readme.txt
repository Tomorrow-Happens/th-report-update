=== TH Report ===
Contributors: Alex Fesenko
Tags: report, info
Requires at least: 1.0
Tested up to: 5.8
Requires PHP: 5.6.20
Stable tag: 5.2.1

Generate JSON current, and monthly technical reports through integration with Cloudways. Purposefully built to plug-in to Adobe Document Generation API.

== Installation ==
• Install plugin
• Configure Settings
• Generate current status report (or wait for monthly reports to generate)