<?php
/**
 * The Template for Generate admin page.
 *
 * @version 1.0.0
 */

if (!defined('ABSPATH')) exit; 
?>
<hr/>
<div class="wrap">
    <h2>Additionally</h2>
    <p class="wrap-clear">
        <button id="btn-clear" class="button button-warning" onclick="clear_fields();">Clear all fields</button>
    </p>
</div>
<script>
function clear_fields(){
    jQuery("input[type=password]").val("").removeAttr('required').attr("type","text");
    jQuery("input[type=text]").val("").removeAttr('required');
}

</script>
<style>

</style>