<?php
/**
 * Function to contact Webpagetest API for TH Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('TH_RA')) :
    /**
     * TH_RA class.
     */
    final class TH_RA
    {

        public $errors = null;

        private $api = '';
        
        private $token = "";

        private $param = [];

        /**
         * Construct TH_RA class.
         */
        public function __construct($param = []) {
            $this->api = trim(get_option( 'th_report_api_url' ),'/')."/api.php";

            $this->token = get_option( 'th_report_api_key' );
            $this->param['key'] = $this->token;

            if(!empty($param)) $this->param = array_merge($this->param, $param);
        }

        /**
         * Curl request to api
         * 
         * @param string $url relative URL for the call
         * 
         * @return response
         */
        private function call($url,$post = [])
        {
            if(!$post){
                $response = wp_remote_get( $url );
            }else{
                $args = array(
                    'timeout'     => 45,
                    'redirection' => 5,
                    'httpversion' => '1.0',
                    'blocking'    => true,
                    'headers' => array(),
                    'body'    => array( 'username' => 'bob', 'password' => '1234xyz' ),
                    'cookies' => array()
                );
                $response = wp_remote_post( $url, ['body' => $post ] );
            }
            return $response;
        }

        /**
         * Run test report.
         * 
         * @param array 
         * 
         * @return array 
         */
        public function get_pdf($data) {
            if(!$data) return false;
            $json = json_encode($data);
            if(!$json) return false;

            if(!empty($param)) $this->param = array_merge($this->param, $param);
            $response = $this->call($this->api."?".http_build_query($this->param),['json' =>$json]);

            if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response )!=200) return false;
            if ( $response["headers"]->offsetGet("content-type") != "application/pdf" || intval($response["headers"]->offsetGet("content-length")) < 1000) return false;

            $filename = explode("=",$response["headers"]->offsetGet("content-disposition"))[1];
            if(!$filename) $filename = "report.pdf";

            $file = [];
            $file["type"] = $response["headers"]->offsetGet("content-type");
            $file["length"] = $response["headers"]->offsetGet("content-length");
            $file["filename"] = $filename;
            $file["body"] = $response['body'];

            if ($file) {
                header($_SERVER["SERVER_PROTOCOL"] . " 200 OK");
                header("Cache-Control: public"); 
                header("Content-Type: application/pdf");
                header("Content-Transfer-Encoding: Binary");
                header("Content-Length:".$file["length"]);
                header("Content-Disposition: attachment; filename=".$file["filename"]);
                echo ($file["body"]);
                die();
            }

            return false;
        }

    }

endif;
