<?php
/**
 * Ajax action callbacks for TH Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('TH_Ajax')) :

    /**
     * TH_Ajax class.
     */
    final class TH_Ajax
    {

        /**
         * Construct Ajax.
         */
        function __construct() {
            add_action('wp_ajax_generate_report', [$this,'generate_report']);
            add_action('wp_ajax_generate_report_lighthouse', [$this,'generate_report_lighthouse']);
            add_action('wp_ajax_generate_lighthouse_status', [$this,'generate_lighthouse_status']);
        }

        /**
         * Ajax callback generate_report.
         */
        function generate_report() {
            $param = ["address"=>"","note"=>"N/A"];
            if(!empty($_POST["th_report_address"])) $param["address"] = sanitize_text_field($_POST["th_report_address"]);
            if(!empty($_POST["th_report_note"])) $param["note"] = sanitize_text_field($_POST["th_report_note"]);
            if(!empty($_POST["th_report_period"])) $param["period"] = sanitize_text_field($_POST["th_report_period"]);
          
            if($param["period"]=="current"){
                $this->current_report($param);
            }elseif((int)$param["period"]>0){
                $this->on_date_report($param);
            }
            $this->error(__( 'Error request execution', 'th-report' ));
        }

        /**
         * Ajax callback generate current report.
         */
        private function current_report($param) {
            $report = new TH_Report();

            $cw_email = get_option( 'th_cloudways_email' );
            $cw_key = get_option( 'th_cloudways_key' );
            $cw_server = get_option( 'th_cloudways_site_id' );
            $cw_app = get_option( 'th_cloudways_app_id' );

            $report->set_type('current');
            $report->set_site(parse_url(get_option( 'siteurl' ))['host']);
            $report->set_period(current_datetime()->format('d F Y'));
            $report->set_addressee($param["address"]);
            $report->set_notes($param["note"]);

            if($cw_email && $cw_key && $cw_key!='none'){
                $cw = new TH_CW($cw_email,$cw_key);

                $settings = $cw->get_settings($cw_server);
                if($cw->errors) $this->error($cw->errors);
                if(empty($settings->package_versions)) $this->error(__( "Error getting server package versions", 'th-report' ));
                $settings->package_versions->app = get_bloginfo('version');
                $report->set_details($settings->package_versions);
    
                $services = $cw->get_services($cw_server);
                if($cw->errors) $this->error($cw->errors);
                $services->ssl = (is_ssl()?"running":"stoped");
                $report->set_core($services);
    
                $server = $cw->get_server($cw_server);
                if($cw->errors) $this->error($cw->errors);

                $security = [];
                $security['protection'] = 'Active';
                if(!empty($server->backup_frequency)) 
                    $security['frequency'] = $server->backup_frequency==1?"Daily":$server->backup_frequency." Days";
                if(!empty($server->backup_retention)) 
                    $security['retention'] = $server->backup_retention==1?"Daily":$server->backup_retention." Days";
                $report->set_security($security);
            }else{
                $settings = new stdClass();
                $settings->app = get_bloginfo('version');
                $report->set_details($settings);
    
                $services = new stdClass();
                $services->ssl = (is_ssl()?"running":"stoped");
                $report->set_core($services);
    
                $security = [];
                $security['protection'] = 'Active';
                $report->set_security($security);
            }

            $report->set_plugins();
 
            if($report->errors) $this->error($report->errors);

            $report_data = $report->get_json();
            $token = get_option( 'wpt_token' );
            if(($token && $token != 'none') && !empty($_POST["lighthouse"])) $report_data["lighthouse"] = json_decode(stripslashes($_POST["lighthouse"]));
                 
            wp_send_json( $report_data );
            die();
        }

        /**
         * Ajax callback generate_report_lighthouse.
         */
        function generate_report_lighthouse() {
            $token = get_option( 'wpt_token' );
            if(!$token || $token == 'none'){
                wp_send_json( ['jsonUrl' => 'none'] );
                die();
            }
            $wpt = new TH_WPT();
            $param = [];
            if(!empty($_POST["mobile"])) $param["mobile"] = (int) $_POST["mobile"];
            $report = $wpt->runTest($param); 
            if(empty($report['jsonUrl'])) $this->error($wpt->errors);
            wp_send_json( $report );
            die();
        }

        /**
         * Ajax callback generate_lighthouse_status.
         */
        function generate_lighthouse_status() {
            if(empty($_POST["jsonUrl"])) $this->error(__( 'Error empty report url', 'th-report' ));
            if($_POST["jsonUrl"] == 'none'){
                wp_send_json( ['data' => 'none'] );
                die();
            }
            $wpt = new TH_WPT();
            $report = $wpt->jsonResult($_POST["jsonUrl"]);
            if(empty($report)) $this->error(__( 'Error report result', 'th-report' ));
            if($report['statusCode'] < 200) sleep(20);
            wp_send_json( $report );
            die();
        }

        /**
         * The Ajax callback will generate a report by date.
         */
        private function on_date_report($param) {
            $report = get_th_report($param["period"]);
            $report->set_addressee($param["address"]);
            $report->set_notes($param["note"]);
            $report->set_previous_report();

            if($report->errors) $this->error($report->errors);
                 
            wp_send_json( $report->get_json() );
            die();
        }

        /**
         * Ajax callback error.
         */
        function error($errors) {
            if(is_string($errors)) $errors = [$errors];
            wp_send_json( ['errors'=>$errors] );
            die();
        }
            
    }

endif;
