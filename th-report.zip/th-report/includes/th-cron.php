<?php
/**
 * TH_Cron class for TH Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('TH_Cron')) :

    /**
     * TH_Cron class.
     */
    final class TH_Cron
    {

        public $errors = [];

        private $email = '';

        private $domain = '';

        public static $start_time = '01:00:00';

        public static $schedule = 'daily';

        /**
         * Construct TH_Cron.
         */
        function __construct() {
            $this->email = get_option( 'th_admin_email' );
            $this->domain = parse_url(get_option( 'siteurl' ))['host'];
            add_action('th_report_cron_run', array($this, 'run'));     
            if(!wp_next_scheduled('th_report_cron_run')){
                self::install();
            }
        }

        /**
         * Add wp schedule event.
         */
        public static function install() {
            if(wp_next_scheduled('th_report_cron_run')) return false;
            wp_schedule_event( time(), self::$schedule, 'th_report_cron_run');
        }

        /**
         * Delete wp schedule event.
         */
        public static function uninstall() {
            wp_clear_scheduled_hook( 'th_report_cron_run' );
        }

        /**
         *  WP schedule event run this action.
         */
        public function run() {
            if(!wp_doing_cron()) return false;
            try {
                $this->create_report();
            } catch (\Throwable $th) {
                if(empty($settings->package_versions)) $this->error(__( "Error create TH Report for ", 'th-report' ).$this->domain); 
            }
        }

        /**
         * Create report.
         * 
         */
        function create_report() {
            if(array_search(date('F Y', strtotime(' -1 months')),get_th_reports_periods()) !== false) return false;

            $cw_email = get_option( 'th_cloudways_email' );
            $cw_key = get_option( 'th_cloudways_key' );
            $cw_server = get_option( 'th_cloudways_site_id' );
            $cw_app = get_option( 'th_cloudways_app_id' );

            $report = new TH_Report();
            $report->set_site($this->domain);
            $report->set_period(date('d F Y'));

            $cw = new TH_CW($cw_email,$cw_key);
            if($cw->errors) $this->error($cw->errors);

            $settings = $cw->get_settings($cw_server);
            if($cw->errors) $this->error($cw->errors);
            if(empty($settings->package_versions)) $this->error(__( "Error getting server package versions ", 'th-report' ).$this->domain);
            $settings->package_versions->app = get_bloginfo('version');
            $report->set_details($settings->package_versions);

            $services = $cw->get_services($cw_server);
            if($cw->errors) $this->error($cw->errors);
            $services->ssl = (is_ssl()?"running":"stoped");
            $report->set_core($services);

            $server = $cw->get_server($cw_server);
            if($cw->errors) $this->error($cw->errors);
            $security = [];
            $security['protection'] = 'Active';
            if(!empty($server->backup_frequency)) 
                $security['frequency'] = $server->backup_frequency==1?"Daily":$server->backup_frequency." Days";
            if(!empty($server->backup_retention)) 
                $security['retention'] = $server->backup_retention==1?"Daily":$server->backup_retention." Days";
            $report->set_security($security);

            $report->set_plugins($security);
 
            if($report->errors) $this->error($report->errors);

            if($report->save()) return true;
            else $this->error(__('Error save new TH Report', 'th-report' ));

        }

        /**
         * Callback error.
         */
        function error($error) {
            if(is_array($error)) $error = implode("\n- ",$error);
            if(is_a($error)) $error = print_r($errors,1);
            $subject = 'Error when cron report generate from '.$this->domain;
            $this->mail($error,$subject);
            die();
        }

        /**
         * Send email.
         */
        private function mail($message,$subject = '') {
            if($this->email) wp_mail( $this->email, $subject, $message );
        }
                
    }

endif;
