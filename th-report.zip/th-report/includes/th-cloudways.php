<?php
/**
 * Function to contact CW API for TH Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('TH_CW')) :

    /**
     * TH_CW class.
     */
    final class TH_CW
    {

        private $baseURL = 'https://api.cloudways.com/api/v1';

        public $errors = null;

        private $token = "";

        private $key = "";

        private $email = "";

        /**
         * Construct Ajax.
         */
        public function __construct($email,$key) {
            $this->email = $email;
            $this->key = $key;
            $this->auth();
        }

        /**
         * Curl request to api
         * 
         * @param string $url relative URL for the call
         * @param type $post Optional post data for the call
         * @return object Output from CW API
         */
        private function call($url, $post = [])
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->baseURL . $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            if ($this->token) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $this->token]);
            }

            $encoded = '';
            if (count($post)) {
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                foreach ($post as $name => $value) {
                    $encoded .= urlencode($name) . '=' . urlencode($value) . '&';
                }
                $encoded = substr($encoded, 0, strlen($encoded) - 1);

                curl_setopt($ch, CURLOPT_POSTFIELDS, $encoded);
                curl_setopt($ch, CURLOPT_POST, 1);
            }else{
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
            }

            $output = curl_exec($ch);

            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpcode != '200') {
                $this->errors[] = 'An error occurred code:  '.$httpcode.' output: '.substr($output, 0, 10000);
            }
            curl_close($ch);
            return json_decode($output);
        }

        /**
         * Getting a token.
         */
        private function auth() {
            if(empty($this->email) || empty($this->key)){
                $this->errors[] = __( 'Error empty email or key', 'th-report' );
                return false;
            }
            $tokenResponse = $this->call('/oauth/access_token', ['email' => $this->email, 'api_key' => $this->key]);
            if(empty($tokenResponse->access_token)){
                $this->errors[] = __( 'Error auth for Cloudways', 'th-report' );
                return false;
            }
            $this->token = $tokenResponse->access_token;
        }

        /**
         * Getting the server list.
         * 
         * @return object 
         */
        public function get_servers() {
            if($this->errors) return false;

            $responsive = $this->call('/server');

            if(empty($responsive->servers)){
                $this->errors[] = __( 'Error getting the server list', 'th-report' );
                return false;
            }

            return $responsive->servers;
        }

        /**
         * Get server from id.
         * 
         * @param string 
         * 
         * @return object 
         */
        public function get_server($server_id) {
            if(!$server_id || $this->errors) return false;

            $servers = $this->get_servers();

            if(!$servers){
                return false;
            }

            foreach($servers as $item){
                if($item->id==$server_id){
                    return $item;
                }
            }

            $this->errors[] = __( 'Error the specified server is not in the list of servers', 'th-report' );
            return false;
        }

        /**
         * Get setting server.
         * 
         * @param string 
         * 
         * @return object 
         */
        public function get_settings($server_id) {
            if(!$server_id || $this->errors) return false;

            $responsive = $this->call('/server/manage/settings?server_id='.$server_id);

            if(empty($responsive->settings)){
                $this->errors[] = __( 'Error getting server settings', 'th-report' );
                return false;
            }

            return $responsive->settings;
        }

        /**
         * Get setting server.
         * 
         * @param string 
         * 
         * @return object 
         */
        public function get_services($server_id) {
            if(!$server_id || $this->errors) return false;

            $responsive = $this->call('/service?server_id='.$server_id);

            if(empty($responsive->services->status)){
                $this->errors[] = __( 'Error getting server services', 'th-report' );
                return false;
            }

            return $responsive->services->status;
        }
    }

endif;
