<?php
/**
 * TH_Report class for TH Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('TH_Report')) :

    /**
     * TH_Report class.
     */
    class TH_Report
    {

        public $errors = [];

        private $id = 0;

        private $post = null;

        public static $post_type = 'th_report';

        private $previous = null;

        private $type = 'full';
		
        private $site = '';

        private $period = '';

        private $addressee = '';

        private $data = [];

        private $details = [
            'app'        => 'Wordpress',
            'php'        => 'PHP',
            'platform'   => 'Platform',
            'mariadb'    => 'MariaDB',
            'redis'      => 'Redis'
        ];
  
        private $core = [
            "apache2"       => 'Apache2',
            "memcached"     => 'MemCached',
            "mysql"         => 'MySQL',
            "nginx"         => 'Nginx',
            "redis-server"  => 'Redis',
            "varnish"       => 'Varnish Cache',
            "ssl"           => 'SSL Encryption'
        ];

        private $security = [ 
            "protection"       => 'Comprehensive Protection',
            "frequency"     => 'Backup Frequency',
            "retention"         => 'Backup Retention',
        ];

        private $plugins = [];

        private $notes = 'N/A';

        /**
         * Construct TH_Report class.
         *
         * @return void
         */
        public function __construct( $read = 0 ) {
			if ( is_numeric( $read ) && $read > 0 ) {
				$this->set_id( $read );
			} elseif ( $read instanceof self ) {
				$this->set_id( absint( $read->get_id() ) );
			} elseif ( ! empty( $read->ID ) ) {
				$this->set_id( absint( $read->ID ) );
			}
	
			if ( $this->get_id() > 0 ) {
				$this->read();
			}
        }

		/**
		 * Reads an object from the data store.
		 *
		 * @return TH_Report data instance.
		 */
		public function read() {
			$post_object = get_post( $this->get_id() );
			if ( ! $this->get_id() || ! $post_object || self::$post_type !== $post_object->post_type ) {
				$this->errors[] = __( 'Invalid read TH_Report post object', 'th-report' );
				return $this;
			}
			$this->post = $post_object;
			$this->read_post_meta();
			return $this;
		}

		/**
		 * Read post meta.
         *
         * @return void
		 */
		protected function read_post_meta() {
			$id = $this->get_id();
			foreach($this->details as $name => $value){
				$this->data[$name] = get_post_meta( $id, '_'.$name, 1 );
			}
			foreach($this->core as $name => $value){
				$this->data[$name] = get_post_meta( $id, '_'.$name, 1 );
			}
			foreach($this->security as $name => $value){
				$this->data[$name] = get_post_meta( $id, '_'.$name, 1 );
			}
			$this->site = get_post_meta( $id, '_site', 1 );
			$this->period = get_post_meta( $id, '_period', 1 );
			$this->plugins = get_post_meta( $id, '_plugins', 1 );
		}

		/**
		 * Register custom post type th_report.
         *
         * @return void
		 */
        public static function init() {
			$args = [
                'label' => __('TH Report', 'th-report'),
                'public' => false,
                'show_in_menu' => null,
                'show_in_rest' => null,
                'rest_base' => null,
                'capability_type' => 'post',
                'hierarchical' => false,
                'has_archive' => false,
                'query_var' => false,
                'can_export' => false,
                'rewrite_no_front' => false,
                'rewrite' => false,
            ];
        
            register_post_type(self::$post_type, $args);
        }

	    /**
    	 * Returns the unique ID for this object.
    	 *
    	 * @return int
    	 */
    	public function get_id() {
    		return $this->id;
    	}

	    /**
    	 * Set the unique ID for this object.
    	 *
    	 * @param int
    	 */
    	private function set_id($id) {
    		$this->id = $id;
    	}

    	/**
    	 * Returns previous for this object.
    	 *
    	 * @return object
    	 */
    	public function get_previous() {
    		return $this->previous;
    	}

    	/**
    	 * Method to update previous for this object.
    	 *
    	 * @param object
    	 */
    	public function set_previous($previous) {
    		$this->previous = $previous;
    	}

    	/**
    	 * Returns type for this object.
    	 *
    	 * @return string
    	 */
    	public function get_type() {
    		return $this->type;
    	}

    	/**
    	 * Method to set type for this object.
    	 *
    	 * @param string
    	 */
    	public function set_type($type) {
    		$this->type = $type;
    	}

	    /**
    	 * Returns attibute data for this object.
    	 *
    	 * @return string
    	 */
    	public function get_param($param) {
    		if(isset($this->data[$param])) return $this->data[$param];
			else return 'N/A';
    	}

	    /**
    	 * Returns plugin for this object.
    	 *
    	 * @return array
    	 */
    	public function get_plugin($path) {
    		if(isset($this->plugins[$path])) return $this->plugins[$path];
			else return false;
    	}

    	/**
    	 * Returns site for this object.
    	 *
    	 * @return string
    	 */
    	public function get_site() {
    		return $this->site;
    	}

    	/**
    	 * Method to update param site for this object.
    	 *
    	 * @param string
    	 */
    	public function set_site($site) {
    		$this->site = $site;
    	}

    	/**
    	 * Returns period for this object.
    	 *
    	 * @return string
    	 */
    	public function get_period() {
    		return $this->period;
    	}

    	/**
    	 * Returns period formated for this object.
    	 *
    	 * @return string
    	 */
    	public function get_period_month() {
			return date('F Y',strtotime($this->period .' -1 months'));
    	}

    	/**
    	 * Method to update param period for this object.
    	 *
    	 * @param string
    	 */
    	public function set_period($period) {
    		$this->period = $period;
    	}

    	/**
    	 * Returns addressee for this object.
    	 *
    	 * @return string
    	 */
    	public function get_addressee() {
    		return $this->addressee;
    	}

    	/**
    	 * Method to update param addressee for this object.
    	 *
    	 * @param string
    	 */
    	public function set_addressee($addressee) {
    		$this->addressee = $addressee;
    	}

    	/**
    	 * Returns notes for this object.
    	 *
    	 * @return string
    	 */
    	public function get_notes() {
    		return $this->notes;
    	}

    	/**
    	 * Method to update param notes for this object.
    	 *
    	 * @param string
    	 */
    	public function set_notes($notes) {
    		$this->notes = $notes;
    	}

    	/**
    	 * Returns details for this object.
    	 *
    	 * @return array
    	 */
    	public function get_details() {
			$details = [];
            foreach($this->details as $name=>$label){
                if(!isset($this->data[$name])) continue;
                $detail = ["label" => $label,"current" => $this->data[$name]];
				if($this->type == 'full'){
					if($this->previous) 
						$detail["previous"] =  $this->previous->get_param($name);
					else
						$detail["previous"] =  'N/A';
				}
				  
				$details[] = $detail;
            }
    		return $details;
    	}

    	/**
    	 * Method to update param details for this object.
    	 *
    	 * @param array
    	 */
    	public function set_details($details) {
			if(is_object($details)) $details = (array)$details;
			foreach($this->details as $name=>$label){
                if(!isset($details[$name])) continue;
                $this->data[$name] = $details[$name];
            }
		}

    	/**
    	 * Returns core for this object.
    	 *
    	 * @return array
    	 */
    	public function get_core() {
			$cores = [];
            foreach($this->core as $name=>$label){
                if(!isset($this->data[$name])) continue;
                $cores[] = ["label" => $label,"current" => ucfirst($this->data[$name])];
            }
    		return $cores;
    	}

    	/**
    	 * Method to update param core for this object.
    	 *
    	 * @param array
    	 */
    	public function set_core($core) {
			if(is_object($core)) $core = (array)$core;
			foreach($this->core as $name=>$label){
                if(!isset($core[$name])) continue;
                $this->data[$name] = $core[$name];
            }
		}

    	/**
    	 * Returns security for this object.
    	 *
    	 * @return array
    	 */
    	public function get_security() {
			$securities = [];
            foreach($this->security as $name=>$label){
                if(!isset($this->data[$name])) continue;
                $securities[] = ["label" => $label,"current" => ucfirst($this->data[$name])];
            }
    		return $securities;
    	}

    	/**
    	 * Method to update param security for this object.
    	 *
    	 * @param array
    	 */
    	public function set_security($security) {
			if(is_object($security)) $security = (array)$security;
			foreach($this->security as $name=>$label){
                if(!isset($security[$name])) continue;
                $this->data[$name] = $security[$name];
            }
		}

    	/**
    	 * Returns security for this object.
    	 *
    	 * @return array
    	 */
    	public function get_plugins() {
			$plugins = [];
            foreach($this->plugins as $path=>$plugin){
                $plugins[] = ["label" => $plugin["Name"],"current" => $plugin["Version"]];
            }
    		return $plugins;
    	}

    	/**
    	 * Method to update param plugins for this object.
    	 *
    	 */
    	public function set_plugins() {
			$active_plugins = get_option('active_plugins');
			$all_plugins=get_plugins();
			unset($all_plugins[TH_PLUGIN_ID]);
			$plugins=[];
			foreach ($active_plugins as $p){           
				if(isset($all_plugins[$p])){
					 array_push($plugins, $all_plugins[$p]);
				}           
			}
            $this->plugins = $plugins;
		}

    	/**
    	 * Returns security for this object.
    	 *
    	 * @return array
    	 */
    	public function get_updated_plugins() {
			$plugins = [];
            foreach($this->plugins as $path=>$plugin){
				if($this->previous) $previous = $this->previous->get_plugin($path);
				if(!$previous || $plugin["Version"] == $previous["Version"])  continue;
                $plugins[] = ["label" => $plugin["Name"],"current" => $plugin["Version"],"previous" => $previous["Version"]];
            }
			if(!$plugins) $plugins[] = ["label" => "N/A","current" => "-","previous" => "-"];
    		return $plugins;
    	}

    	/**
    	 * Returns security for this object.
    	 *
    	 * @return array
    	 */
    	public function get_unchanged_plugins() {
			$plugins = [];
            foreach($this->plugins as $path=>$plugin){
				if($this->previous) $previous = $this->previous->get_plugin($path);
				if($previous && $plugin["Version"] != $previous["Version"])  continue;
				$plugins[] = ["label" => $plugin["Name"],"current" => $plugin["Version"]];
            }
			if(!$plugins) $plugins[] = ["label" => "N/A","current" => "-"];
    		return $plugins;
    	}

    	/**
    	 * Returns json data for this object.
    	 *
    	 * @return string
    	 */
    	public function get_json() {
			$json = [];

            $json["site"] = $this->get_site();
            if($this->type == 'current') $json["period"] = $this->get_period();
			else $json["period"] = $this->get_period_month();
            $json["addressee"] = $this->get_addressee();
			$json["details"] = $this->get_details();
			$json["core"] = $this->get_core();
			$json["security"] = $this->get_security();

			if($this->type == 'current'){
				$json["plugins"] = $this->get_plugins();
			}else{
				$json["updatedPlugins"] = $this->get_updated_plugins();
				$json["unchangedPlugins"] = $this->get_unchanged_plugins();
			}

			$json["notes"] = $this->get_notes();

    		return $json;
    	}

		/**
		 * Save should create or update based on object existence.
		 *
		 * @return int
		 */
		public function save() {

			if ( $this->get_id() ) {
				$this->update();
			} else {
				$this->create();
			}

			return $this->get_id();
		}
	
		/**
		 * Method to create a post th_report in the database.
		 */
		public function update() {
			$this->errors[] = __( 'This method has not been implemented yet!', 'th-report' );
		}

		/**
		 * Method to create a post th_report in the database.;
		 */
		public function create() {

			$id = wp_insert_post(
				apply_filters(
					'th_report_new_post_data',
					array(
						'post_type'      => self::$post_type,
						'post_status'    => 'publish',
						'post_title'     => 'Report '.$this->get_period(),
						'comment_status' => 'closed',
						'ping_status'    => 'closed'
					)
				),
				true
			);

	        if ( $id && ! is_wp_error( $id ) ) {
				$this->set_id( $id );
				$this->update_post_meta();
				do_action( 'th_report_new_post_'.self::$post_type, $id, $this );
			}else{
				$this->errors[] = __( 'Error create post th_report in the database', 'th-report' );
			}
		}
																			

		/**
		 * Method to update post meta a post th_report in the database.;
		 */
		protected function update_post_meta() {
			$id = $this->get_id();
			foreach($this->data as $name => $value){
				update_post_meta( $id, '_'.$name, $value );
			}
			update_post_meta( $id, '_site', $this->site );
			update_post_meta( $id, '_period', $this->period );
			update_post_meta( $id, '_plugins', $this->plugins );
		}

		/**
		 * Delete an object, set the ID to 0, and return result.
		 *
		 * @return bool result
		 */
		public function delete() {
			$delete = wp_delete_post( $this->get_id(), 1 );
			if ( $delete ) {
				$this->set_id( 0 );
				return true;
			}
			return false;
		}


		/**
		 * Method to set previous report for this object.;
		 */
		public function set_previous_report(){
			$date = new DateTime($this->get_period());
			$date->modify('-1 month');
			if(!$date) return true;

			$posts = get_posts([
				'posts_per_page' => 1,
				'orderby' => 'date',
				'order' => 'DESC',
				'post_type' => self::$post_type,
				'post_status' => 'publish',
				'date_query' => [
					'month' => $date->format('m'),
					'year' => $date->format('Y')
				]
			]);

			if($posts){
				$this->previous = new TH_Report($posts[0]);
				return true;
			}
			return false;
		}
	}

endif;

TH_Report::init();


/**
 * Get TH_Report object.
 *
 * @return object
 */
function get_th_report($id = 0){
    return new TH_Report($id);
}

/**
 * Get an array of TH_Report objects.
 *
 * @return array
 */
function get_th_reports(){
	$posts = get_posts([
		'posts_per_page' => -1,
        'orderby' => 'date',
        'order' => 'DESC',
        'post_type' => TH_Report::$post_type,
        'post_status' => 'publish',
    ]);

	$reports=[];
	foreach ($posts as $post) {
		try {
			$reports[]=new TH_Report($post);
		} catch (\Throwable $th) {}
	}

	return $reports;
}

/**
 * Get an array of TH_Report date lists.
 *
 * @return array
 */
function get_th_reports_periods(){
	$reports = get_th_reports();

	$periods=[];
	foreach ($reports as $report) {
			$periods[$report->get_id()]=$report->get_period_month();
	}
    return $periods;
}

