<?php
/**
 * Function to contact Webpagetest API for TH Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('TH_WPT')) :
    /**
     * TH_WPT class.
     */
    final class TH_WPT
    {

        public $errors = null;

        private $api = 'https://www.webpagetest.org/runtest.php';

        private $api_locations = 'https://www.webpagetest.org/getLocations.php?f=json';
        
        private $token = "";

        private $param = [
                            "f"             => "json",
                            "runs"          => 1,
                            "fvonly"        => 1,
                            "type"          => "lighthouse",
                            "lighthouse"    => 1,
                        ];

        /**
         * Construct TH_WPT class.
         */
        public function __construct($param = []) {
            $this->token = get_option( 'wpt_token' );
            $this->param['k'] = $this->token;
            if(get_option( 'wpt_test_url' )) $this->param['url'] = get_option( 'wpt_test_url' );
            else $this->param['url'] = get_option( 'siteurl' );
            if(get_option( 'wpt_location' )) $this->param['location'] = get_option( 'wpt_location' );
            if(!empty($param)) $this->param = array_merge($this->param, $param);
        }

        /**
         * Curl request to api
         * 
         * @param string $url relative URL for the call
         * 
         * @return array Output from Webpagetest API
         */
        private function call($url)
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $output = curl_exec($ch);

            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpcode != '200') {
                $this->errors[] = 'An error occurred code:  '.$httpcode.' output: '.substr($output, 0, 10000);
            }
            curl_close($ch);
            return json_decode($output,1);
        }

        /**
         * Run test report.
         * 
         * @param array 
         * 
         * @return array 
         */
        public function runTest($param = []) {
            if($this->errors) return false;

            if(!empty($param)) $this->param = array_merge($this->param, $param);
            $endpoint = $this->api."?".http_build_query($this->param);
            $responsive = $this->call($endpoint);

            if(empty($responsive['data'])){
                $this->errors[] = __( 'Error run report on webpagetest.org', 'th-report' );
                return false;
            }

            return $responsive['data'];
        }

        /**
         * Get result report from url.
         * 
         * @param string 
         * 
         * @return array 
         */
        public function jsonResult($json_url) {
            if($this->errors) return false;
            if(!$json_url) return false;

            $responsive = $this->call($json_url);

            if(empty($responsive['statusCode'])){
                $this->errors[] = __( 'Error getting the server list', 'th-report' );
                return false;
            }

            if($responsive['statusCode'] == 200 && !empty($responsive['data']['lighthouse'])){
                $data = $this->parseJsonResult($responsive['data']['lighthouse']);
                if($data) return ["data" => $data];
                else $this->errors[] = __( 'Error parse report data', 'th-report' );
                return false;
            }

            return $responsive['data'];
        }

        /**
         * Parse report data.
         * 
         * @param string 
         * 
         * @return array 
         */
        public function parseJsonResult($json) {
            if($this->errors) return false;
            if(!$json) return false;

            $data = [];
            $data['Performance'] = ($json['categories']['performance']['score']*100)." / 100";
            $data['Accessibility'] = ($json['categories']['accessibility']['score']*100)." / 100";
            $data['Best Practices'] = ($json['categories']['best-practices']['score']*100)." / 100";
            $data['SEO'] = ($json['categories']['seo']['score']*100)." / 100";

            $data['First Contentful Paint'] = $json['audits']['first-contentful-paint']['displayValue'];
            $data['Time to Interactive'] = $json['audits']['interactive']['displayValue'];
            $data['Speed Index'] = $json['audits']['speed-index']['displayValue'];
            $data['Total Blocking Time'] = $json['audits']['total-blocking-time']['displayValue'];
            $data['Largest Contentful Paint'] = $json['audits']['largest-contentful-paint']['displayValue'];
            $data['Cumulative Layout Shift'] = $json['audits']['cumulative-layout-shift']['displayValue'];
            
            return $data;
        }

        /**
         * Getting the Locations list.
         * 
         * @return array 
         */
        public function getLocations() {
            if($this->errors) return false;

            $responsive = $this->call($this->api_locations);

            if(empty($responsive['data'])){
                $this->errors[] = __( 'Error getting the server list', 'th-report' );
                return false;
            }
            $locations = [];
            $locations[''] = 'Default';
            foreach($responsive['data'] as $item){
                if($item["status"] == "OK") $locations[$item["location"]] = $item["Label"] . ' ('.$item["group"].')';
            }

            return $locations;
        }

    }

endif;
